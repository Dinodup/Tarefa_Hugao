ALTER TABLE animal ADD foto varchar(100);

ALTER TABLE pessoa ADD senha varchar(50);