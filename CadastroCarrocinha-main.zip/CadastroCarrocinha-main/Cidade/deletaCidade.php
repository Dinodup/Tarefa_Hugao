<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/deletar.css">
    <title>Deletar Cidade</title>
</head>
<body>
    <div class="menu">
        <a href="#" class="brand"><img src="../img/logo-gato.webp" alt=""></a>
        <nav>
            <ul>
                <li><a href="#">Cidade</a>
                    <ul>
                        <li><a href="../Cidade/CadastroCidade.html">Cadastrar</a></li>
                        <li><a href="../Cidade/ListarCidade.php">Visualizar</a></li>
                    </ul>
                </li>
                <li><a href="">Pessoa</a>
                    <ul>
                        <li>
                            <a href="../Pessoa/CadastroPessoa.php">Cadastrar</a>
                        </li>
                        <li>
                            <a href="../Pessoa/ListarPessoa.php">Visualizar</a>
                        </li>
                    </ul>
                </li>
                <li><a href="">Animal</a>
                    <ul>
                        <li>
                            <a href="../Animal/CadastroAnimal.php">Cadastrar</a>
                        </li>
                        <li>
                            <a href="../Animal/ListarAnimal.php">Visualizar</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>
    <section>
        <div class="principal">
            <h1>Deletar Cidade</h1>
            <?php
            include('../includes/conexao.php'); // Inclua seu arquivo de conexão




            $id = intval($_GET['id']); // Garanta que o ID é um inteiro




            // Comece uma transação
            mysqli_begin_transaction($con);




            try {
                // Primeiro, exclua os registros relacionados na tabela `pessoa`
                $sql_pessoa = "DELETE FROM pessoa WHERE id_cidade = ?";
                $stmt_pessoa = mysqli_prepare($con, $sql_pessoa);
                mysqli_stmt_bind_param($stmt_pessoa, 'i', $id);
                mysqli_stmt_execute($stmt_pessoa);




                // Agora, exclua o registro na tabela `cidade`
                $sql_cidade = "DELETE FROM cidade WHERE id = ?";
                $stmt_cidade = mysqli_prepare($con, $sql_cidade);
                mysqli_stmt_bind_param($stmt_cidade, 'i', $id);
                mysqli_stmt_execute($stmt_cidade);




                // Confirme a transação
                mysqli_commit($con);




                echo "<h2>Dados deletados com sucesso!</h2>";




            } catch (Exception $e) {
                // Caso haja erro, desfaça a transação
                mysqli_rollback($con);
                echo "<h2>Erro ao deletar!</h2>";
                echo "<h2>" . mysqli_error($con) . "</h2>";
            }
            ?>
        </div>
    </section>
</body>
</html>
